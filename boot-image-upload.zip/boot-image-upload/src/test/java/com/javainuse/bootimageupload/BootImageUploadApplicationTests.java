package com.javainuse.bootimageupload;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BootImageUploadApplicationTests {

	@Test
	void contextLoads() {
	}

}
